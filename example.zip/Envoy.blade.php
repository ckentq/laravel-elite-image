@servers(['web' => '127.0.0.1'])

@task('production')
{{--基本設定--}}
php artisan storage:link
php artisan route:cache
php artisan view:cache
{{--啟動設定--}}
supervisord -c /etc/supervisord.conf
supervisorctl start laravel-schedule:*
supervisorctl start laravel-worker:*
supervisorctl start laravel-swoole:*

tail -f /dev/null
@endtask

@task('local')
{{--下載套件--}}
composer install
yarn --ignore-engines install &
{{--基本設定--}}
php artisan migrate
php artisan storage:link
{{--啟動設定--}}
supervisord -c /etc/supervisord.conf
supervisorctl start laravel-schedule:*
supervisorctl start laravel-worker:*
supervisorctl start laravel-webpack:*
php -S 0.0.0.0:80 -t public

@endtask

@task('test')
supervisord -c /etc/supervisord.conf
supervisorctl start laravel-schedule:*
supervisorctl start laravel-worker:*
supervisorctl start laravel-swoole:*

tail -f /dev/null
@endtask
